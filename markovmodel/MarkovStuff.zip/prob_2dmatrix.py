#!/usr/bin/python

#English Alphabet
ENGLISH = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
                   'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
                   's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

#Make lookup table for use with 2d matrices
ENG_LOOKUP = {}
count = 0
for let in ENGLISH:
	ENG_LOOKUP[let] = count
	count += 1
ENG_LOOKUP['END'] = count

# Sample Training Words
WORDS = ['spare', 'spear', 'pares', 'peers', 'reaps', 'peaks',
			'speaker', 'keeper', 'pester', 'paste', 'tapas', 'pasta',
			'past', 'straps', 'tears', 'terse', 'steer', 'street',
			'stare', 'rates', 'streak', 'taste', 'tapa', 'peat', 'eat',
			'ate', 'tea', 'seat']

#Create 2D Matrix for transition probabilities (including last letter-->END transtition)			
n = len(ENGLISH) + 1
transition_prob = [[0] * n for i in range(n)]

#Populate 2D transition probability matrix
for word in WORDS:
	for i in range(len(word) - 1):
		transition_prob[ENG_LOOKUP[word[i]]][ENG_LOOKUP[word[i + 1]]] += 1
	transition_prob[ENG_LOOKUP[word[-1]]][ENG_LOOKUP['END']] += 1
print "Trasition Probability Matrix: \n\n", transition_prob
			


