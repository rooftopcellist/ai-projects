#!/usr/bin/python

#count = 0
#count += 1
##print count
#
#d = {}
#d['a'] = 2
#letter = 'b'
#d[letter] = 5
#
#d[letter] += 1
#
#print d['a']
#print d['b']

WORDS = ['spare', 'spear', 'pares', 'peers', 'reaps', 'peaks',
			'speaker', 'keeper', 'pester', 'paste', 'tapas', 'pasta',
			'past', 'straps', 'tears', 'terse', 'steer', 'street',
			'stare', 'rates', 'streak', 'taste', 'tapa', 'peat', 'eat',
			'ate', 'tea', 'seat']
			
prob_dict = {}
for word in WORDS:
	for i in range(len(word)-1):
		if (word[i], word[i + 1]) in prob_dict:
			prob_dict[(word[i], word[i + 1])] += 1
		else:
			prob_dict[(word[i], word[i + 1])] = 0
#		print word[i], "to", word[i + 1]
	END = word[-1]
	if (word[-1], 'END') in prob_dict:
		prob_dict[(word[-1], 'END')] += 1
	else:
		prob_dict[(word[-1], 'END')] = 0
#	print END
print prob_dict
	